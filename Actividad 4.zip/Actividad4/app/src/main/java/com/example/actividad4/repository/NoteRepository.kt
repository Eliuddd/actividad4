package com.example.actividad4.repository

import com.example.actividad4.data.Note
import com.example.actividad4.data.NoteDao
import kotlinx.coroutines.flow.Flow

class NoteRepository (private val noteDao: NoteDao) {
    fun getAllNotes (): Flow<List<Note>> = noteDao.getAllNotes()

    suspend fun insert (note: Note) {
        noteDao.insertNote (note)
    }

    suspend fun update (note: Note) {
        noteDao.updateNote (note)
    }

    suspend fun delete (note: Note) {
        noteDao.deleteNote (note)
    }
}